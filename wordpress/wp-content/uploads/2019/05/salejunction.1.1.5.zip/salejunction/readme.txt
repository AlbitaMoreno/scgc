﻿SaleJunction WordPress theme, Copyright (C) 2014 INKTHEMES
SaleJunction WordPress theme is licensed under the GPL.


License and resources links for images:
---------------------------------------
	2.jpg - http://pixabay.com/en/railway-station-luggage-child-103308/
	License: Distributed under the terms of the CC0
	Copyright: Pixabay, http://pixabay.com/

License and resources links for scripts:
---------------------------------------
== 1 ==
	jquery.ba-cond.min.js cond - v0.1  : http://benalman.com/projects/jquery-cond-plugin/
	Copyright (c) 2009 "Cowboy" Ben Alman, http://benalman.com/about/license/
	License: Licensed under the MIT license

 
== 2 ==
	jQuery Easing v1.3 - http://gsgd.co.uk/sandbox/jquery/easing/
	License: Open source under the BSD License. 
	Copyright: © 2008 George McGinley Smith


 
== 3 ==
	jQuery FlexSlider v1.8 : http://flex.madebymufffin.com
	License: Release under the MIT license.
	Copyright: (C) 2011, Tyler Smith
 
== 4 ==
	jQuery Tools 1.2.3 - The missing UI library for the Web http://flowplayer.org/tools/
	Copyright (c) 2008, Three Dub Media (http://threedubmedia.com)
	License: Liscensed under the MIT License
	http://www.opensource.org/licenses/mit-license.php
 
== 5 ==
	mobile-menu.js, custom.js, tabs.js - http://inkthemes.com/
	License: Distributed under the terms of the GPL
	Copyright: InkThemes, http://inkthemes.com/

 
== 6 ==
	Modernizr 2.6.2 (Custom Build): http://modernizr.com/download/#-csstransforms3d-csstransitions-touch-shiv-cssclasses-prefixed-teststyles-testprop-testallprops-prefixes-domprefixes-load
	License: Modernizr is available under the MIT license.
	Copyright: modernizr.com http://modernizr.com/license/

== 7 ==
	jQuery Superfish Menu Plugin: http://users.tpg.com.au/j_birch/plugins/superfish/
	License: Dual licensed under the MIT and GPL licenses: http://www.opensource.org/licenses/mit-license.php http://www.gnu.org/licenses/gpl.html
	Copyright (c) 2013 Joel Birch

== 8 ==
	TGM-Plugin-Activation: https://github.com/thomasgriffin/TGM-Plugin-Activation
	Thomas Griffin <thomas@thomasgriffinmedia.com>
	Gary Jones <gamajo@gamajo.com>
	Copyright (c) 2012, Thomas Griffin
	License: http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
	
== 9 ==
	Arvo font: http://www.google.com/fonts/specimen/Arvo
	License: SIL Open Font License, 1.1 http://scripts.sil.org/OFL
	Copyright: Anton Koovit
	
== 10 ==
	WooCommerce: http://www.woothemes.com/woocommerce/
	License: GPL
	Copyright: WooThemes
==================================================================
Theme Documentation
 More about the theme usage:

1. Begining (Important)

A) Installing the theme

To be able to use the salejunction theme, you need to install WordPress on your server. If you don't know how to do it, then click on the link below that will guide you how to install WordPress.
 
http://www.inkthemes.com/12-simple-steps-to-install-wordpress-locally/01/