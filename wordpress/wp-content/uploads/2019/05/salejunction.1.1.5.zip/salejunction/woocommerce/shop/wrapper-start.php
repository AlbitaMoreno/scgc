<?php
/**
 * Content wrappers
 *
 * @package 	salejunction
 * @author		InkThemes
 * @license		license.txt
 * @since 		1.0
 * 
 */
?>
<div class="content_wrapper">
    <div class="page-content woocommerce">
        <div class="container_24">
            <div class="grid_24">
                <div class="grid_16 alpha">
                    <div class="content-bar"> 
                        <div class="content-area<?php echo (!is_singular() ) ? ' has-sidebar' : '' ?>" id="primary">
                            <div class="site-content" id="content">
