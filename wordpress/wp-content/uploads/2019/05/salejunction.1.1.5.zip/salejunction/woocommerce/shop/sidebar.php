<?php

/**
 * Sidebar
 *
 * @package 	salejunction
 * @author		InkThemes
 * @license		license.txt
 * @since 		1.0
 */
if (!is_singular('product'))
    get_sidebar('shop'); 
