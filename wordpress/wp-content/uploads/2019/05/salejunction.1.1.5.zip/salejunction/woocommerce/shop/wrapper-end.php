<?php
/**
 * Content wrappers end
 *
 * @package 	salejunction
 * @author		InkThemes
 * @license		license.txt
 * @since 		1.0
 * 
 */
?>
</div>
</div>
<div class="clear"></div>
</div><!-- /#content .site-content -->
</div><!-- /#primary .content-area has-sidebar -->

