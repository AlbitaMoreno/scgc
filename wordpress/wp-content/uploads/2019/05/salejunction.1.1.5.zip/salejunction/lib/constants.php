<?php

define('CUSTOM_CAT', 'download_category');
define('CUSTOM_TAG', 'download_tag');
?>
