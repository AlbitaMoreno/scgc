<div class="sidebar becomemember">
    <?php
    do_action('woocommerce_single_product_summary');
    ?>
</div>